namespace DayPilotCalendarMvc.Controllers
{
    partial class DataClasses1DataContext
    {
    }
}
